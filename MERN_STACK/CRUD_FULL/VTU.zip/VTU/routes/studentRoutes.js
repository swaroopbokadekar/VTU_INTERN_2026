const express = require("express");
const Student = require("../models/Student");

const router = express.Router();

/* ---------------- CREATE ---------------- */
router.post("/students", async (req, res) => {
    try {
        const student = new Student(req.body);
        await student.save();
        res.status(201).json(student);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

/* ---------------- READ ALL ---------------- */
router.get("/students", async (req, res) => {
    const students = await Student.find();
    res.json(students);
});

/* ---------------- GET BY COURSE ---------------- */
router.get("/students/course/:course", async (req, res) => {
    const students = await Student.find({
        course: req.params.course
    });
    res.json(students);
});

/* ---------------- GET BY CITY ---------------- */
router.get("/students/city/:city", async (req, res) => {
    const students = await Student.find({
        city: req.params.city
    });
    res.json(students);
});

/* ---------------- AGE GREATER THAN 18 ---------------- */
router.get("/students/age/above18", async (req, res) => {
    const students = await Student.find({
        age: { $gt: 18 }
    });
    res.json(students);
});

/* ---------------- UPDATE ---------------- */
router.put("/students/:id", async (req, res) => {
    const updated = await Student.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
    );
    res.json(updated);
});

/* ---------------- DELETE ---------------- */
router.delete("/students/:id", async (req, res) => {
    await Student.findByIdAndDelete(req.params.id);
    res.json({ message: "Student deleted" });
});

module.exports = router;
