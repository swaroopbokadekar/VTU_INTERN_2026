// const express = require("express");
const { MongoClient } = require("mongodb");  //npm install
// const cors = require("cors");

// const app = express();
// app.use(cors());
// app.use(express.json());

// const url = "mongodb://localhost:27017/";
// const client = new MongoClient(url);

// app.get("/students", async (req, res) => {
//   await client.connect();
//   const db = client.db("schoolDB");
//   const students = await db.collection("students").find().toArray();
//   res.json(students);
// });

// /* POST: save new student */
// app.post("/students", async (req, res) => {
//   try {
//     const student = req.body;

//     await client.connect();
//     const db = client.db("schoolDB");
//     const result = await db.collection("students").insertOne(student);

//     res.json({ message: "Student saved", id: result.insertedId });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send("Error saving student");
//   }
// });


// app.listen(3000, () => {
//   console.log("Server running on port 3000");
// });


const express = require("express");
const mongoose = require("mongoose");
const studentRoutes = require("./routes/studentRoutes");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());
mongoose.connect("mongodb://127.0.0.1:27017/schoolDB")
    .then(() => console.log("MongoDB connected"))
    .catch(err => console.log(err));

app.use(studentRoutes);

app.listen(3000, () => {
    console.log("Server running on port 3000");
});
