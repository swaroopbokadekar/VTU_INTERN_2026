function Accounts() {
  return <h2>Accounts Page (Admin Only)</h2>;
}

export default Accounts;