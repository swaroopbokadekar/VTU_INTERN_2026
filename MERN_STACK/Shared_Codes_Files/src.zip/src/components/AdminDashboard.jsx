import React from "react";

function AdminDashboard() {

  // Normally fetched from backend after admin login
  const admin = {
    name: "Admin User",
    role: "ADMIN",
    lastLogin: "02 Mar 2026, 10:30 AM"
  };

  return (
    <div style={styles.container}>

      {/* Header */}
      <h2>Admin Dashboard</h2>
      <p>
        Welcome, <strong>{admin.name}</strong>
      </p>
      <p style={{ fontSize: "14px", color: "#555" }}>
        Last Login: {admin.lastLogin}
      </p>

      {/* System Overview */}
      <div style={styles.card}>
        <h3>System Overview</h3>
        <p><b>Total Students:</b> 1240</p>
        <p><b>Total Courses:</b> 18</p>
        <p><b>Active Semesters:</b> 6</p>
      </div>

      {/* Admin Actions */}
      <div style={styles.card}>
        <h3>Admin Actions</h3>
        <button style={styles.button}>Manage Students</button>
        <button style={styles.button}>Manage Courses</button>
        <button style={styles.button}>Generate Reports</button>
        <button style={styles.button}>View All Results</button>
      </div>

      {/* Notifications */}
      <div style={styles.card}>
        <h3>Pending Tasks</h3>
        <ul>
          <li>Approve 5 new student registrations</li>
          <li>Publish Semester 5 results</li>
          <li>Update course syllabus</li>
        </ul>
      </div>

    </div>
  );
}

const styles = {
  container: {
    padding: "20px",
    fontFamily: "Arial"
  },
  card: {
    background: "#7dd96d",
    padding: "15px",
    marginTop: "15px",
    borderRadius: "6px"
  },
  button: {
    marginRight: "10px",
    marginTop: "8px",
    padding: "8px 12px",
    cursor: "pointer"
  }
};

export default AdminDashboard;