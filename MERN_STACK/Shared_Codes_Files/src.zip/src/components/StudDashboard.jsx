import React from "react";

function StudDashboard() {

  // Normally this data comes from backend API
  const student = {
    name: "Amit Kumar",
    rollNo: "STU1023",
    course: "Computer Science",
    semester: 5
  };

  return (
    <div style={styles.container}>

      {/* Header */}
      <h2>Student Dashboard</h2>
      <p>Welcome, <strong>{student.name}</strong></p>

      {/* Student Info Card */}
      <div style={styles.card}>
        <h3>My Profile</h3>
        <p><b>Roll No:</b> {student.rollNo}</p>
        <p><b>Course:</b> {student.course}</p>
        <p><b>Semester:</b> {student.semester}</p>
      </div>

      {/* Actions Section */}
      <div style={styles.card}>
        <h3>Quick Actions</h3>
        <button style={styles.button}>View Attendance</button>
        <button style={styles.button}>View Marks</button>
        <button style={styles.button}>My Courses</button>
      </div>

      {/* Announcements */}
      <div style={styles.card}>
        <h3>Announcements</h3>
        <ul>
          <li>Mid-sem exams start from 15th March</li>
          <li>Assignment 2 submission by Friday</li>
        </ul>
      </div>

    </div>
  );
}

const styles = {
  container: {
    padding: "20px",
    fontFamily: "Arial"
  },
  card: {
    background: "#4d9ceb",
    padding: "15px",
    marginTop: "15px",
    borderRadius: "6px"
  },
  button: {
    marginRight: "10px",
    padding: "8px 12px",
    cursor: "pointer"
  }
};

export default StudDashboard;