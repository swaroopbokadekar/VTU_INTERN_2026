import { Navigate } from "react-router-dom";

function ProtectedRoute({ roleRequired, children }) {
  const role = sessionStorage.getItem("role");

  if (role !== roleRequired) {
    return <Navigate to="/unauthorized" />;
  }

  return children;
}

export default ProtectedRoute;