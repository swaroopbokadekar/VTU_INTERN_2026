import { useNavigate } from "react-router-dom";

function Login() {
  const navigate = useNavigate();

  const loginAsAdmin = () => {
    sessionStorage.setItem("role", "ADMIN");
    navigate("/dashboard");
  };

  const loginAsStudent = () => {
    sessionStorage.setItem("role", "STUDENT");
    navigate("/dashboard");
  };

  return (
    <div>
      <h2>Login</h2>
      <button onClick={loginAsAdmin}>Login as Admin</button>
      <button onClick={loginAsStudent}>Login as Student</button>
    </div>
  );
}

export default Login;