import AdminDashboard from "./components/AdminDashboard";
import StudDashboard from "./components/StudDashboard";
import Unauthorized from "./Unauthorized";

function Dashboard() {
  const role = sessionStorage.getItem("role");

  if (role === "ADMIN") return <AdminDashboard />;
  if (role === "STUDENT") return <StudDashboard />;

  return <Unauthorized/>;
}

export default Dashboard;